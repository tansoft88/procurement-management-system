<?php
/**
 * PatientObservationFixture
 *
 */
class PatientObservationFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'episode_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'patient_detail_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'blood_pressure' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'temperature' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'weight' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'hieght' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'bmi' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'episode_id' => 1,
			'patient_detail_id' => 1,
			'blood_pressure' => 'Lorem ipsum dolor sit amet',
			'temperature' => 'Lorem ipsum dolor sit amet',
			'weight' => 'Lorem ipsum dolor sit amet',
			'hieght' => 'Lorem ipsum dolor sit amet',
			'bmi' => 'Lorem ipsum dolor sit amet'
		),
	);
}
